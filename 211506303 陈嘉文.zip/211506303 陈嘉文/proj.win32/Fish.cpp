#include "Fish.h"


Fish::Fish(void)
{
}


Fish::~Fish(void)
{
}
