#include "ScheduleCounterDelegate.h"


ScheduleCounterDelegate::ScheduleCounterDelegate(void)
{
}


ScheduleCounterDelegate::~ScheduleCounterDelegate(void)
{
}
