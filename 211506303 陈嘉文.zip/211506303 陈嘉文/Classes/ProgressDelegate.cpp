#include "ProgressDelegate.h"


ProgressDelegate::ProgressDelegate(void)
{
}


ProgressDelegate::~ProgressDelegate(void)
{
}
