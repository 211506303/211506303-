#include "PanelLayer.h"
#include "GameScene.h"
#include "ScheduleCountDown.h"
PanelLayer::PanelLayer(void)
{

}

PanelLayer::~PanelLayer(void)
{

}
//��ʼ�����Ӳ˵���˵�����ң�����ʱ
bool PanelLayer::init()
{
	if(!CCLayer::init())
	{
		return false;
	}
	CCSize winSize = CCDirector::sharedDirector()->getWinSize();
	_goldCounter = GoldCounterLayer::create(0);
	addChild(_goldCounter);
    _goldCounter->setPosition(ccp(600,45));//���λ��

	CCSprite * sprite1 = CCSprite::create("btn_gonggao_01-ipadhd.png");   
    this->addChild(sprite1);
	sprite1->setPosition(ccp(1700, 1400));

	CCSprite * sprite2 = CCSprite::create("button_other_002-ipadhd.png");   
    this->addChild(sprite2);
	sprite2->setPosition(ccp(400, 1400));

	CCSprite * sprite3 = CCSprite::create("ui_button_music_2-ipadhd.png");   
    this->addChild(sprite3);
	sprite3->setPosition(ccp(200, 1400));


	ScheduleCountDown* countDown = ScheduleCountDown::create(this);
	_scheduleLabel = CCLabelTTF::create("20", "Thonburi", 70);
	_scheduleLabel->addChild(countDown);
	this->addChild(_scheduleLabel);
	_scheduleLabel->setPosition(ccp(1900, 1400));//����ʱλ��

	CCMenuItemSprite* pause = CCMenuItemSprite::create(CCSprite::create("button_other_003-ipadhd.png"), 
							CCSprite::create("button_other_003-ipadhd.png"),
							this, menu_selector(PanelLayer::pause));

	CCMenu* menu = CCMenu::create(pause, NULL);
	this->addChild(menu);

	CCSize pauseSize = pause->getContentSize();
	menu->setPosition(CCPointMake(winSize.width-pauseSize.width*0.8, pauseSize.height*0.8));

	return true;
}

void PanelLayer::pause(CCObject *sender)
{
	GameScene* gameScene = (GameScene*)this->getParent();
	gameScene->pause();
}

void PanelLayer::setScheduleNumber(int number)
{
	_scheduleLabel->setString(CCString::createWithFormat("%d",number)->getCString());
}

void PanelLayer::scheduleTimeUp()
{
	_scheduleLabel->setVisible(false);
	GameScene* gameScene = (GameScene*)this->getParent();
	gameScene->scheduleTimeUp();
}
