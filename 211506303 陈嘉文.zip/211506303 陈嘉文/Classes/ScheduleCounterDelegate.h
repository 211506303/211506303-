#pragma once
class ScheduleCounterDelegate
{
public:
	ScheduleCounterDelegate(void);
	virtual ~ScheduleCounterDelegate(void);
	virtual void scheduleTimeUp() = 0;
	virtual void setScheduleNumber(int number){
		return;
	}
};
